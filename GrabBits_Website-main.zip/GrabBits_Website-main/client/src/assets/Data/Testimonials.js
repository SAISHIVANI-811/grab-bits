import verified from '../verified.png';

export const Testimonials = [
	{
		img: verified,
		name: 'Ayush Parate',
		para: 'cjvcv  dcksbcbdsv vn f asbdvs  vsv sigv wgh w9g nvjsbva gwsnkbp;s [wg7 wf hiacv ia gsvb svsuv  psdvh ssgvpsbsb vihsddvs s svidshv us9gsbi svg ps sdvbsuv s7g s vsdv sivgsd psdjbs vusgv svg svbs vpuds hjdsbfwd wjbw fuw bf[u9w fg79[',
	},
];
