export const lightTheme = {};
export const darkTheme = {};
